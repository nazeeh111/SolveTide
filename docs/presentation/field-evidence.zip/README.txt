SolveTide stored discrete-equation evidence.

Unpack in a fresh directory, then run:
python3 -I check-editor.py editor-before.json editor-after.json
python3 -I checker.py checked-equations.json

The first checks forward CSR residuals of editor exports; the second checks the richer CLI artifact including adjoint contraction. No solver dependencies are needed to check stored data. This does not establish physical accuracy or bound solution error. New solves require the external full SolveTide source and declared numerical dependencies at e639abebfbfef204d21a3af851fed5d6369f2ae3.
